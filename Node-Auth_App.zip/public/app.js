getSessionID = function() {
  let name = "node-ctr-sesion_id";
  var match = document.cookie.match(new RegExp("(^| )" + name + "=([^;]+)"));
  if (match) return match[2];

  return "no-session";
};

function getAPI() {
  let sid = getSessionID();

  fetch("/api", {
    headers: {
      "node-ctr-sesion_id": sid
    }
  }).then(res => {
    if (res.redirected) {
      window.location.href = res.url;
    } else {
      res.json().then(data => console.log(data));
    }
  });
}
